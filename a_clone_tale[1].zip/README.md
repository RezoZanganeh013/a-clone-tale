# Rat Tide: ساخت نسخهٔ ویندوز و اندروید

بدون نصب چیزی روی کامپیوتر (با GitHub Actions):
1. در github.com یک Repository خالی بساز و همهٔ محتوای این پوشه را (با پوشهٔ .github) در آن آپلود کن. اگر پوشهٔ .github آپلود نشد، فایل .github/workflows/build.yml را دستی بساز.
2. به تب Actions برو. ساخت خودکار شروع می‌شود (حدود ۱۰ دقیقه)؛ اگر شروع نشد، workflow به نام build را Run کن.
3. بعد از پایان، پایین صفحهٔ اجرا در بخش Artifacts دو فایل را دانلود کن: windows-exe (فایل exe قابل اجرا بدون نصب) و android-apk.
4. اندروید: فایل apk را باز کن و نصب از منبع ناشناس را مجاز کن.

بدون ساخت: rat-tide.html را در Chrome یا Edge باز کن. اگر پوشهٔ www را روی یک هاست (مثل GitHub Pages) بگذاری، گزینهٔ Install / Add to Home screen هم در کروم اندروید و ویندوز فعال می‌شود.

اجرای محلی با Electron: npm install و بعد npm start
